//
// Created by Karla Angélica Peña Guerra on 5/8/22.
//
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Visit.h"

using namespace std;

#ifndef PATIENT_DATA_PATIENT_H
#define PATIENT_DATA_PATIENT_H

struct patient_inf{
    int file_number;
    string firstName;
    string lastName;
    string gender;
    int age;
};

class Patient {
    /*
     * This class will save the Patient's information (file number, first & last name, gender and age) in a vector
     * Add visits to vector separately (one by one)
     * Create output file (file_number.txt) with above information
     * Give access to the information in the file
     */

public:
    // Constructor and destructor
    Patient();
    ~Patient();

    // Functions
    void storeInf();

};


#endif //PATIENT_DATA_PATIENT_H
