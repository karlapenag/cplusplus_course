//
// Created by Karla Angélica Peña Guerra on 5/8/22.
//

#include "Patient.h"
