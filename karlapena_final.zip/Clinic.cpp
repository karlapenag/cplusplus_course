//
// Created by Karla Angélica Peña Guerra on 5/8/22.
//

#include "Clinic.h"

void Clinic::runMenu() {
    cout << "Welcome to patient management" << endl;
    cout << endl;
    int command = 0;

    while(command != QUIT)
    {
        cout << "================================================" << endl;
        cout << "Please choose a command: " << endl;
        cout << NEWPATIENT << ". Add new patient" << endl;
        cout << NEWVISIT << ". Add new visit" << endl;
        cout << DISPINFO << ". Display patient information" << endl;
        cout << QUIT << ". Quit" << endl;
        cout <<"===============>";
        cin >> command;
        while(command < NEWPATIENT || command > QUIT) {
            cout << "Invalid command" << endl;
            cin >> command;
        }

        switch(command)
        {
            case NEWPATIENT:
                break;
            case NEWVISIT:
                break;
            case DISPINFO:
                break;
            case QUIT:
                cout << "Thank you for using patient management. Bye!" << endl;
                break;
        }
    }
}