//
// Created by Karla Angélica Peña Guerra on 5/8/22.
//
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

#ifndef PATIENT_DATA_VISIT_H
#define PATIENT_DATA_VISIT_H


class Visit {
    /*
     * This class will store Visits data for a Patient (visit ID number, patient file number, date, doctor's first & last name)
     * date as a string in the format dd/mm/yyyy
     */

public:
    // Constructor and destructor
    Visit();
    ~Visit();
};


#endif //PATIENT_DATA_VISIT_H
