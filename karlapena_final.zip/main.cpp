#include <iostream>
#include<fstream>
#include "Clinic.h"
using namespace std;


int main() {
    Clinic clinic;
    clinic.runMenu();

    return 0;
}
