#include "Supermarket.hpp"

int main()
{
    Supermarket SM(15, 2, 4);
    SM.Simulate(120);

}
