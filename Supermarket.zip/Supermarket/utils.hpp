
void Randomize();
double random(double low, double high);
bool randomChance(double p);
