#ifndef _SUPERMARKET_H
#define _SUPERMARKET_H

#include <queue>

class Supermarket{
    int custFreq;
    int minChcktTm;
    int maxChcktTm;
    std::queue<int> checkoutqueue;
    int serviceTimeRemaining;
    int nServed;
    double totalWait;
    double totalLength;

public:
    Supermarket(int customerFrequency, int minimumCheckoutTime, int maximumCheckoutTime);
    void Simulate(int simulationPeriod);
    int customerArrived();
    void serveNewCustomer(int t);
    void serveCurrentCustomer();
    bool cashierBusy();
    void printStats(int simulationPeriod);
};

#endif // _SUPERMARKET_H

