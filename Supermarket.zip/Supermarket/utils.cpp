#include <cstdlib>
#include <ctime>

void Randomize()
{
     srand(time(NULL));
}

double random(double low, double high)
{
       double retval;

       retval = low + (high - low)  * rand() / RAND_MAX;
       return retval;
}

bool randomChance(double p)
{
     double trial;

     trial = random(0 , 1);
     if (trial < p)
        return true;
     else
         return false;
}
