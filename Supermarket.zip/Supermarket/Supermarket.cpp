#include "Supermarket.hpp"
#include "utils.hpp"
#include <iostream>

using namespace std;

Supermarket::Supermarket(int customerFrequency, int minimumCheckoutTime, int maximumCheckoutTime)
{
    custFreq = customerFrequency;
    minChcktTm = minimumCheckoutTime;
    maxChcktTm = maximumCheckoutTime;
    serviceTimeRemaining = 0;
    nServed = 0;
    totalLength = 0;
    totalWait = 0;
}

void Supermarket::Simulate(int simulationPeriod)
{
    Randomize();
    for (int t = 0; t < simulationPeriod; t++)
    {
        int nbrCustomersArrived = customerArrived();
        for(int i = 0; i < nbrCustomersArrived; i++)
        {
            checkoutqueue.push(t);
        }

        if(!cashierBusy())
        {
            serveNewCustomer(t);
        }
        else
        {
            serveCurrentCustomer();
        }
        totalLength += checkoutqueue.size();
    }
    if(cashierBusy())
        nServed++;
    printStats(simulationPeriod);
}

int Supermarket::customerArrived()
{
    int nbrCustomers = custFreq/60;
    double probArrival = double(custFreq)/60 - custFreq/60;
    if (randomChance(probArrival))
        nbrCustomers++;
}

bool Supermarket::cashierBusy()
{
    return serviceTimeRemaining > 0;
}

void Supermarket::serveCurrentCustomer()
{
    serviceTimeRemaining--;
    if(serviceTimeRemaining == 0)
        nServed++;
}

void Supermarket::serveNewCustomer(int t)
{
    if (!checkoutqueue.empty())
    {
        totalWait += t - checkoutqueue.front();
        checkoutqueue.pop();
        serviceTimeRemaining = random(minChcktTm, maxChcktTm);
    }
}

void Supermarket::printStats(int simulationPeriod)
{
    cout << "With a customer frequency of  " << custFreq << " customers per hour ";
    cout << " and a checkout time varying between " << minChcktTm << " minutes and " << maxChcktTm << " minutes. " << endl;
    cout << "A total of " << nServed << " customers were served over a period of  " << simulationPeriod << " Minutes." << endl;
    cout << "They spent on average " << totalWait/nServed << " minutes waiting." << endl;
    cout << "The average queue length was  " << totalLength / simulationPeriod << "." << endl;
}
