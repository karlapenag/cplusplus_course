/*
 * File: CheckoutQueue.cpp
 * ------------------------------
 * This program is a modified version of the checkout line
 * simulation program provided in the textbook
 * "Programming abstractions in C++". To keep everything in one
 * source file the implementation of the random libray was included here.
 *
 * This program simulates a checkout line, such as one you
 * might encounter in a grocery store. Customers arrive at
 * the checkout stand and get in line. Those customers wait
 * in the line until the cashier is free, at which point
 * they are served and occupy the cashier for a randomly
 * chosed period of time. After the service time is complete,
 * the cashier is free to serve the next customer in the line.
 *
 * The waiting line is represented by a Queue<int> in which the
 * integer value stored in the queue is the time unit in which
 * that customer arrived. Storing this time makes it possible
 * to determine the average waiting time for each customer.
 *
 * In each unit of time, up to the parameter SIMULATION_TIME,
 * the following operations are performed:
 *
 * 1. Determine whether a new customer has arrived.
 * New customers arrive randomly, with a probability
 * determined by the parameter ARRIVAL_PROBABILITY.
 *
 * 2. If the cashier is busy, note that the cashier has
 * spent another minute with that customer. Eventually,
 * the customer's time request is satisfied, which frees
 * the cashier.
 *
 * 3. If the cashier is free, serve the next customer in line.
 * The service time is taken to be a random period between
 * MIN_SERVICE_TIME and MAX_SERVICE_TIME.
 *
 * At the end of the simulation, the program displays the
 * parameters and the following computed results:
 *
 * o The number of customers served
 * o The average time spent in line
 * o The average number of customers in the line
 *
 * Author: Malek Smaoui, October 6th, 2012, KAUST, v 1.0
 */

#include <queue>
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

/* Simulation parameters */
const int SIMULATION_TIME = 2000;
const double ARRIVAL_PROBABILITY = 0.10;
const int MIN_SERVICE_TIME = 5;
const int MAX_SERVICE_TIME = 15;

/* Private function prototypes */
void RunSimulation();
void ReportResults(int nServed, long totalWait, long totalLength);
void Randomize();
int randomInteger(int low, int high);
double randomReal(double low, double high);
bool randomChance(double p);

/* Main program */
int main() {
    Randomize();
    RunSimulation();
    return 0;
}

/*
* Function: RunSimulation
* Usage: RunSimulation();
* -----------------------
* This function runs the actual simulation. In each time unit,
* the program first checks to see whether a new customer arrives.
* Then, if the cashier is busy (indicated by a nonzero value for
* serviceTimeRemaining), the program decrements that variable to
* indicate that one more time unit has passed. Finally, if the
* cashier is free, the simulation serves another customer from
* the queue after recording the waiting time for that customer.
*/
void RunSimulation() {
    queue<int> checkoutqueue;
    int serviceTimeRemaining = 0;
    int nServed = 0;
    long totalWait = 0;
    long totalLength = 0;
    for (int t = 0; t < SIMULATION_TIME; t++)
		{
        if (randomChance(ARRIVAL_PROBABILITY))
		{
        	checkoutqueue.push(t);
    	}
    	if (serviceTimeRemaining > 0)
		{
        	serviceTimeRemaining--;
        	if (serviceTimeRemaining == 0)
						nServed++;
        }
    	else if (!checkoutqueue.empty())
		{
        	totalWait += t - checkoutqueue.front();
        	checkoutqueue.pop();
        	serviceTimeRemaining =
        	randomInteger(MIN_SERVICE_TIME, MAX_SERVICE_TIME);
        }

        totalLength += checkoutqueue.size();
    }
    ReportResults(nServed, totalWait, totalLength);
}

/*
* Function: ReportResults
* Usage: ReportResults(nServed, totalWait, totalLength);
* ------------------------------------------------------
* This function reports the results of the simulation.
*/
void ReportResults(int nServed, long totalWait, long totalLength) {
    cout << "Simulation results given the following parameters:"
    << endl;
    cout << fixed << setprecision(2);
    cout << " SIMULATION_TIME: " << setw(4)
    << SIMULATION_TIME << endl;
    cout << " ARRIVAL_PROBABILITY: " << setw(7)
    << ARRIVAL_PROBABILITY << endl;
    cout << " MIN_SERVICE_TIME: " << setw(4)
    << MIN_SERVICE_TIME << endl;
    cout << " MAX_SERVICE_TIME: " << setw(4)
    << MAX_SERVICE_TIME << endl;
    cout << endl;
    cout << "Customers served: " << setw(4) << nServed << endl;
    cout << "Average waiting time: " << setw(7)
    << double(totalWait) / nServed << endl;
    cout << "Average queue length: " << setw(7)
    << double(totalLength) / SIMULATION_TIME << endl;
}


/*
* Functions: Randomize
* Usage: Randomize();
* -------------------
* This function sets the random seed so that the random sequence
* is unpredictable. If this function is not called, the other
* functions will return the same values on each run. During the
* debugging phase, it is best not to call this function, so that
* program behavior is repeatable.
*/
void Randomize()
{
     srand(time(NULL));
}

/*
 * Function: randomInteger
 * Usage: int n = randomInteger(low, high);
 * ----------------------------------------
 * Returns a random integer in the range low to high, inclusive.
 */

int randomInteger(int low, int high)
{
    int retval;

    retval = (int) (low + (high - low) * rand() / RAND_MAX);
    return retval;
}

/*
 * Function: randomReal
 * Usage: double d = randomReal(low, high);
 * ----------------------------------------
 * Returns a random real number in the half-open interval [low .. high).  A
 * half-open interval includes the first endpoint but not the second, which
 * means that the result is always greater than or equal to low but
 * strictly less than high.
 */

double randomReal(double low, double high)
{
       double retval;

       retval = low + (high - low)  * rand() / RAND_MAX;
       return retval;
}

/*
 * Function: randomChance
 * Usage: if (randomChance(p)) . . .
 * ---------------------------------
 * Returns true with the probability indicated by p.  The argument p must
 * be a floating-point number between 0 (never) and 1 (always).  For
 * example, calling randomChance(.30) returns true 30 percent of the time.
 */

bool randomChance(double p)
{
     double trial;

     trial = randomReal(0 , 1);
     if (trial < p)
        return true;
     else
         return false;
}
