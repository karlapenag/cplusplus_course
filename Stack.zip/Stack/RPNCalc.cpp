/*
 * File: RPNCalc.cpp
 * ------------------
 * This program is a calucaltor that
 * uses reverse polish notation to evaluate expression.
 * The program is not secured enough against wrong inputs
 * Author: Mohammad El-Ramly 7/7/2012
 */

#include <iostream>
#include <stack>
#include <cstdlib>

using namespace std;

/* Functions Prototypes */
bool IsOperator (char op);
double ApplyOperator (char op, double operand1, double operand2);

/* Function main takes an expression from the user,
 * with operators and operands seperarated by spacesor new line
 * and ending with = sign
 */

int main() {
    stack<double> calc;        // stack to store operands till evaluated
    string       input;        // string to read user input (operands and oeprators)
    cout << "Please enter expression in reverse Polish Notation (= to stop):\n";
    while (true) {             // loop till = is entered
          cin >> input;
          if (IsOperator (input[0]))   // Check if first char of input is operator
             if (input[0] == '=') {    // if = sign pop result from stack and print
                cout << "\nResult: " << calc.top() << "\n\n";
                calc.pop();
                //system ("pause");
                return 0;
             }
             else {                     // if another valid operator pop two operands
                double temp1 = calc.top(); calc.pop();
                double temp2 = calc.top(); calc.pop();
                calc.push (ApplyOperator (input[0],temp2,temp1));  // Apply operator on operands
             }
          else
              calc.push (atof (input.c_str()));     // Not an operator, push operand in stack
    }
    return 0;
}


/* Function IsOperator takes a char and returns true
 * if it is one of the operator +, -, *, / or =
 */
 bool IsOperator (char op) {
     switch (op) {
            case '+':
            case '-':
            case '*':
            case '/':
            case '=': return true;
            default : return false;
     }
}


/* Function ApplyOperator takes a char operator and two
 * double operands and returns the result of applying
 * the operators on the operands and 0 if not a valid operator
 */
double ApplyOperator (char op, double operand1, double operand2) {
     switch (op) {
            case '+': return operand1 + operand2;
            case '-': return operand1 - operand2;
            case '*': return operand1 * operand2;
            case '/': return operand1 / operand2;
            default : return 0;
     }
}
