/*
* File: StackDemo.cpp
* -------------------
* This program demonstrates the functionality of 
* stack class available in the Standard Template Library.
*/

#include <iostream>
#include <stack>
using namespace std;

int main ()
{
  stack<int> mystack;

  cout << "\n\nPushing down elements...";
  for (int i=0; i<5; ++i) {
      cout << " " << i;
      mystack.push(i);
  }
  
  cout << "\n\nPopping out elements...";
  while (!mystack.empty())
  {
     cout << " " << mystack.top();
     mystack.pop();
  }
  cout << endl;
  system ("pause");
  return 0;
}
