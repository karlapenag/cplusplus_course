/*
 * File: StackReverseFile.cpp
 * ------------------------------
 * This program uses a stack to load the content of a file
 * and then prints it reversed. It is a demo of stack use.
 * Author: Malek Smaoui, October 6th, 2012, KAUST, v 1.0
 */

#include <iostream>
#include <fstream>
#include <stack>
using namespace std;

void AskUserForInputFile(string prompt, ifstream & infile);
void ReadTextFile(ifstream & infile, stack<string> & lines);
void PrintReversed(stack<string> & lines);

/* Main program */
int main() {
    ifstream infile;
    stack<string> lines;
    // Main algorithm: Get file name, open it, read it in stack, print it
    AskUserForInputFile("Input file: ", infile);
    ReadTextFile(infile, lines);
    PrintReversed (lines);

    infile.close();
    system ("pause");
    return 0;
}

/* Function: AskUserForInputFile
 * It takes file name as string and input file stream and opens
 * the file whose name is given in the input file stream
 */
void AskUserForInputFile(string prompt, ifstream & infile) {
     string filename;
     while (true) {              // Loop until valid file name is given
           cout << prompt;
           cin >> filename; 
           infile.open(filename.c_str());  // Open file
           if (!infile.fail()) break;      // If you cannot open, return
           cout << "Unable to open " << filename << endl;
           infile.clear();
     }
}

/* Function: ReadTextFile
 * It input file stream and a stack and loads file content in the stack
 */
void ReadTextFile(ifstream & infile, stack<string> & lines) {
     while (true) {
           string line;
           getline(infile, line);
           if (infile.fail()) break;
           lines.push(line);
     }
}

/* Function: PrintReversed
 * It takes a stack and prints its content 
 */
void PrintReversed(stack<string> & lines) {
     while(! lines.empty()) {
          cout << lines.top() << endl;
          lines.pop();
     }
}
